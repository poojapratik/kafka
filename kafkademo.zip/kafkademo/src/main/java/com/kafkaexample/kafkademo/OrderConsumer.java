package com.kafkaexample.kafkademo;

import org.apache.kafka.clients.consumer.*;
import java.time.Duration;
import java.util.*;

public class OrderConsumer {

    public static void main(String[] args) {

        // 1. Configure the consumer
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "order-processing-group"); // consumer group
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest"); // read from beginning
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");   // manual commit

        // 2. Create and subscribe
        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {

            consumer.subscribe(List.of("orders"));

            // 3. Poll loop
            while (true) {
                ConsumerRecords<String, String> records =
                        consumer.poll(Duration.ofMillis(1000)); // wait up to 1s for messages

                for (ConsumerRecord<String, String> record : records) {
                    System.out.printf(
                            "Received: key=%s value=%s partition=%d offset=%d%n",
                            record.key(), record.value(),
                            record.partition(), record.offset()
                    );

                    // 4. Process your message here
                    processOrder(record.value());
                }

                // 5. Commit offsets after successful processing
                if (!records.isEmpty()) {
                    consumer.commitSync();
                }
            }
        }
    }

    static void processOrder(String json) {
        System.out.println("Processing order: " + json);
        // your business logic here
    }
}
