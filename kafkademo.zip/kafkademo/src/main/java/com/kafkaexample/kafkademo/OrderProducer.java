package com.kafkaexample.kafkademo;

import org.apache.kafka.clients.producer.*;
import java.util.Properties;
public class OrderProducer {

    public static void main(String[] args) throws Exception {

        // 1. Configure the producer
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer");

        // Optional: make it reliable
        props.put(ProducerConfig.ACKS_CONFIG, "all");       // wait for all replicas
        props.put(ProducerConfig.RETRIES_CONFIG, 3);

        // 2. Create the producer
        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {

            for (int i = 1; i <= 10; i++) {
                String key   = "order-" + i;          // key decides partition
                String value = "{\"orderId\":" + i + ",\"item\":\"laptop\"}";

                ProducerRecord<String, String> record =
                        new ProducerRecord<>("orders", key, value);

                // 3. Send asynchronously with a callback
                producer.send(record, (metadata, exception) -> {
                    if (exception == null) {
                        System.out.printf("Sent to topic=%s partition=%d offset=%d%n",
                                metadata.topic(), metadata.partition(), metadata.offset());
                    } else {
                        exception.printStackTrace();
                    }
                });
            }

            producer.flush(); // ensure all messages are sent
        }
    }
}
