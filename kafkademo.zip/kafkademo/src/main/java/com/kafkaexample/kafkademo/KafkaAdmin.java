package com.kafkaexample.kafkademo;

import org.apache.kafka.clients.admin.*;
import java.util.*;

public class KafkaAdmin {

    public static void main(String[] args) throws Exception {

        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

        try (AdminClient admin = AdminClient.create(props)) {

            NewTopic topic = new NewTopic("orders", 3, (short) 1);
            // 3 partitions, replication factor 1 (increase for production!)

            admin.createTopics(List.of(topic)).all().get();
            System.out.println("Topic created.");

            // List topics
            admin.listTopics().names().get().forEach(System.out::println);
        }
    }

}
