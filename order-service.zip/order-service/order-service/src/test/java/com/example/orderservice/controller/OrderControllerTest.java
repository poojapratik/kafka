package com.example.orderservice.controller;

import com.example.orderservice.domain.enums.OrderStatus;
import com.example.orderservice.dto.request.CreateOrderRequest;
import com.example.orderservice.dto.response.OrderResponse;
import com.example.orderservice.exception.GlobalExceptionHandler;
import com.example.orderservice.exception.OrderNotFoundException;
import com.example.orderservice.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Spring MVC slice test for {@link OrderController}.
 * Only the web layer is loaded; the service is mocked.
 */
@WebMvcTest(OrderController.class)
@Import(GlobalExceptionHandler.class)
class OrderControllerTest {

    @Autowired private MockMvc mockMvc;
    @MockBean  private OrderService orderService;

    private ObjectMapper objectMapper;
    private OrderResponse sampleResponse;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

        sampleResponse = new OrderResponse(
                1L, "customer-1", OrderStatus.PENDING, new BigDecimal("99.98"),
                "idem-001",
                List.of(new OrderResponse.OrderItemResponse(
                        1L, "product-1", 2, new BigDecimal("49.99"), new BigDecimal("99.98"))),
                Instant.now(), Instant.now()
        );
    }

    @Test
    @DisplayName("POST /v1/orders – 201 on valid request")
    void createOrder_returnsCreated() throws Exception {
        CreateOrderRequest request = new CreateOrderRequest(
                "customer-1",
                List.of(new CreateOrderRequest.OrderItemRequest(
                        "product-1", 2, new BigDecimal("49.99"))),
                "idem-001"
        );

        when(orderService.createOrder(any())).thenReturn(sampleResponse);

        mockMvc.perform(post("/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.status").value("PENDING"))
                .andExpect(jsonPath("$.customerId").value("customer-1"));
    }

    @Test
    @DisplayName("POST /v1/orders – 400 when required fields missing")
    void createOrder_returnsBadRequest_whenInvalid() throws Exception {
        // Missing customerId and items
        String invalidBody = "{\"idempotencyKey\":\"idem-001\"}";

        mockMvc.perform(post("/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(invalidBody))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("VALIDATION_FAILED"));
    }

    @Test
    @DisplayName("GET /v1/orders/{id} – 200 on cache/DB hit")
    void getOrder_returnsOk() throws Exception {
        when(orderService.getOrderById(1L)).thenReturn(sampleResponse);

        mockMvc.perform(get("/v1/orders/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.totalPrice").value(99.98));
    }

    @Test
    @DisplayName("GET /v1/orders/{id} – 404 when order does not exist")
    void getOrder_returnsNotFound() throws Exception {
        when(orderService.getOrderById(99L)).thenThrow(new OrderNotFoundException(99L));

        mockMvc.perform(get("/v1/orders/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("NOT_FOUND"));
    }
}
