package com.example.orderservice.service;

import com.example.orderservice.domain.entity.Order;
import com.example.orderservice.domain.entity.OrderItem;
import com.example.orderservice.domain.enums.OrderStatus;
import com.example.orderservice.dto.request.CreateOrderRequest;
import com.example.orderservice.dto.response.OrderResponse;
import com.example.orderservice.event.OrderCreatedEvent;
import com.example.orderservice.exception.DuplicateOrderException;
import com.example.orderservice.exception.OrderNotFoundException;
import com.example.orderservice.kafka.producer.OrderEventProducer;
import com.example.orderservice.repository.OrderRepository;
import com.example.orderservice.service.impl.OrderServiceImpl;
import com.example.orderservice.config.AppProperties;
import com.example.orderservice.util.OrderMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link OrderServiceImpl}.
 * All external dependencies are mocked – no Spring context is loaded.
 */
@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock private OrderRepository      orderRepository;
    @Mock private OrderMapper          orderMapper;
    @Mock private OrderEventProducer   orderEventProducer;
    @Mock private RedisTemplate<String, Object> redisTemplate;
    @Mock private ValueOperations<String, Object> valueOps;
    @Mock private AppProperties        appProperties;
    @Mock private AppProperties.CacheProperties  cacheProperties;
    @Mock private AppProperties.KafkaProperties  kafkaProperties;
    @Mock private AppProperties.KafkaProperties.TopicProperties topicProperties;

    @InjectMocks
    private OrderServiceImpl orderService;

    private CreateOrderRequest validRequest;
    private Order              savedOrder;
    private OrderResponse      orderResponse;

    @BeforeEach
    void setUp() {
        validRequest = new CreateOrderRequest(
                "customer-1",
                List.of(new CreateOrderRequest.OrderItemRequest("product-1", 2, new BigDecimal("49.99"))),
                "idem-key-001"
        );

        OrderItem item = OrderItem.builder()
                .id(1L).productId("product-1").quantity(2)
                .unitPrice(new BigDecimal("49.99")).subTotal(new BigDecimal("99.98"))
                .build();

        savedOrder = Order.builder()
                .id(1L).customerId("customer-1")
                .status(OrderStatus.PENDING)
                .totalPrice(new BigDecimal("99.98"))
                .idempotencyKey("idem-key-001")
                .createdAt(Instant.now()).updatedAt(Instant.now())
                .build();
        savedOrder.addItem(item);

        orderResponse = new OrderResponse(
                1L, "customer-1", OrderStatus.PENDING, new BigDecimal("99.98"),
                "idem-key-001",
                List.of(new OrderResponse.OrderItemResponse(1L, "product-1", 2,
                        new BigDecimal("49.99"), new BigDecimal("99.98"))),
                Instant.now(), Instant.now()
        );

        when(redisTemplate.opsForValue()).thenReturn(valueOps);
        when(appProperties.cache()).thenReturn(cacheProperties);
        when(cacheProperties.idempotencyTtlHours()).thenReturn(24L);
    }

    // ─── createOrder ─────────────────────────────────────────────────────────

    @Nested
    @DisplayName("createOrder()")
    class CreateOrderTests {

        @Test
        @DisplayName("should create order and return response on first call")
        void createOrder_success() {
            // Arrange
            when(valueOps.get(anyString())).thenReturn(null);          // No Redis hit
            when(orderRepository.existsByIdempotencyKey(anyString())).thenReturn(false);
            when(orderMapper.toOrderItems(any())).thenReturn(
                    List.of(OrderItem.builder()
                            .productId("product-1").quantity(2)
                            .unitPrice(new BigDecimal("49.99")).build())
            );
            when(orderRepository.save(any(Order.class))).thenReturn(savedOrder);
            when(orderMapper.toCreatedEvent(any())).thenReturn(
                    new OrderCreatedEvent(1L, "customer-1", OrderStatus.PENDING,
                            new BigDecimal("99.98"), "idem-key-001", List.of(), Instant.now())
            );
            when(orderMapper.toResponse(any(Order.class))).thenReturn(orderResponse);

            // Act
            OrderResponse result = orderService.createOrder(validRequest);

            // Assert
            assertThat(result).isNotNull();
            assertThat(result.id()).isEqualTo(1L);
            assertThat(result.status()).isEqualTo(OrderStatus.PENDING);

            verify(orderRepository).save(any(Order.class));
            verify(valueOps).set(anyString(), anyString(), any());
            verify(orderEventProducer).publishOrderCreated(any(OrderCreatedEvent.class));
        }

        @Test
        @DisplayName("should return existing order on Redis idempotency hit")
        void createOrder_idempotencyHit_redis() {
            // Arrange – Redis contains the previously saved orderId
            when(valueOps.get(anyString())).thenReturn("1");
            when(orderRepository.findByIdWithItems(1L)).thenReturn(Optional.of(savedOrder));
            when(orderMapper.toResponse(savedOrder)).thenReturn(orderResponse);

            // Act
            OrderResponse result = orderService.createOrder(validRequest);

            // Assert
            assertThat(result.id()).isEqualTo(1L);
            verify(orderRepository, never()).save(any());
            verify(orderEventProducer, never()).publishOrderCreated(any());
        }

        @Test
        @DisplayName("should throw DuplicateOrderException when DB has idempotency key but Redis does not")
        void createOrder_idempotencyHit_db() {
            // Arrange
            when(valueOps.get(anyString())).thenReturn(null);
            when(orderRepository.existsByIdempotencyKey("idem-key-001")).thenReturn(true);

            // Act & Assert
            assertThatThrownBy(() -> orderService.createOrder(validRequest))
                    .isInstanceOf(DuplicateOrderException.class)
                    .hasMessageContaining("idem-key-001");

            verify(orderRepository, never()).save(any());
        }
    }

    // ─── updateOrderStatus ───────────────────────────────────────────────────

    @Nested
    @DisplayName("updateOrderStatus()")
    class UpdateOrderStatusTests {

        @Test
        @DisplayName("should update status and evict cache")
        void updateOrderStatus_success() {
            when(orderRepository.updateStatusById(1L, OrderStatus.CONFIRMED)).thenReturn(1);

            // @CacheEvict is applied by Spring proxy; in unit tests we verify the repo call
            assertThatCode(() -> orderService.updateOrderStatus(1L, OrderStatus.CONFIRMED))
                    .doesNotThrowAnyException();

            verify(orderRepository).updateStatusById(1L, OrderStatus.CONFIRMED);
        }

        @Test
        @DisplayName("should throw OrderNotFoundException when no rows updated")
        void updateOrderStatus_notFound() {
            when(orderRepository.updateStatusById(99L, OrderStatus.CANCELLED)).thenReturn(0);

            assertThatThrownBy(() -> orderService.updateOrderStatus(99L, OrderStatus.CANCELLED))
                    .isInstanceOf(OrderNotFoundException.class);
        }
    }
}
