-- =============================================================
-- Order Service PostgreSQL DDL Schema
-- Run this once against your target database, then set
-- spring.jpa.hibernate.ddl-auto=validate in production.
-- =============================================================

-- Enable UUID extension (needed if you switch to UUID PKs)
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS orders (
    id                BIGSERIAL       PRIMARY KEY,
    customer_id       VARCHAR(64)     NOT NULL,
    status            VARCHAR(32)     NOT NULL DEFAULT 'PENDING',
    total_price       NUMERIC(19, 4)  NOT NULL,
    idempotency_key   VARCHAR(128)    NOT NULL,
    created_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_orders_status
        CHECK (status IN ('PENDING', 'CONFIRMED', 'CANCELLED', 'FAILED')),
    CONSTRAINT chk_orders_total_price
        CHECK (total_price >= 0)
);

-- Unique constraint prevents duplicate submissions even if Redis TTL expires
CREATE UNIQUE INDEX IF NOT EXISTS uq_orders_idempotency_key
    ON orders (idempotency_key);

CREATE INDEX IF NOT EXISTS idx_orders_customer_id
    ON orders (customer_id);

CREATE INDEX IF NOT EXISTS idx_orders_status
    ON orders (status);

CREATE TABLE IF NOT EXISTS order_items (
    id          BIGSERIAL       PRIMARY KEY,
    order_id    BIGINT          NOT NULL,
    product_id  VARCHAR(64)     NOT NULL,
    quantity    INT             NOT NULL,
    unit_price  NUMERIC(19, 4)  NOT NULL,
    sub_total   NUMERIC(19, 4)  NOT NULL GENERATED ALWAYS AS (quantity * unit_price) STORED,

    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT chk_order_items_quantity
        CHECK (quantity > 0),
    CONSTRAINT chk_order_items_unit_price
        CHECK (unit_price >= 0)
);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id
    ON order_items (order_id);

-- Trigger: keep orders.updated_at current on every row update
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_orders_updated_at ON orders;
CREATE TRIGGER trg_orders_updated_at
    BEFORE UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
