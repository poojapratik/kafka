package com.example.orderservice.domain.entity;

import com.example.orderservice.domain.enums.OrderStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Persistent representation of a customer order.
 *
 * <p>Design decisions:
 * <ul>
 *   <li>Uses {@code SEQUENCE} generation strategy for better batch-insert performance
 *       compared to {@code IDENTITY}.</li>
 *   <li>{@code CascadeType.ALL} + {@code orphanRemoval} ensures items are always
 *       managed through the aggregate root.</li>
 *   <li>{@code FetchType.LAZY} on items prevents N+1 queries; callers must
 *       explicitly join-fetch when items are needed.</li>
 *   <li>{@code idempotencyKey} has a unique DB constraint (see schema.sql) as
 *       a second line of defence if the Redis TTL has expired.</li>
 * </ul>
 */
@Entity
@Table(
        name = "orders",
        indexes = {
                @Index(name = "idx_orders_customer_id", columnList = "customer_id"),
                @Index(name = "idx_orders_status",      columnList = "status")
        },
        uniqueConstraints = {
                @UniqueConstraint(name = "uq_orders_idempotency_key", columnNames = "idempotency_key")
        }
)
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "items")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_seq")
    @SequenceGenerator(name = "order_seq", sequenceName = "orders_id_seq", allocationSize = 50)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "customer_id", nullable = false, length = 64)
    private String customerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    @Builder.Default
    private OrderStatus status = OrderStatus.PENDING;

    @Column(name = "total_price", nullable = false, precision = 19, scale = 4)
    private BigDecimal totalPrice;

    @Column(name = "idempotency_key", nullable = false, length = 128, updatable = false)
    private String idempotencyKey;

    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    /**
     * One-to-Many relationship with {@link OrderItem}.
     * Items are always fetched lazily; use {@code JOIN FETCH} in JPQL where needed.
     */
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @Builder.Default
    private List<OrderItem> items = new ArrayList<>();

    // ─── Convenience helpers ─────────────────────────────────────────────────

    /**
     * Adds an item and sets the back-reference, keeping both sides of the
     * bi-directional association in sync.
     */
    public void addItem(OrderItem item) {
        items.add(item);
        item.setOrder(this);
    }

    /** Recalculates and sets {@link #totalPrice} from the current list of items. */
    public void recalculateTotalPrice() {
        this.totalPrice = items.stream()
                .map(OrderItem::getSubTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
