package com.example.orderservice.util;

/**
 * Centralised factory for Redis key strings used across the Order Service.
 *
 * <p>Keeping key patterns in one place prevents typos and makes it easy to
 * reason about what the service stores in Redis.
 *
 * <p>Key namespace: {@code order-service:<entity>:<identifier>}
 */
public final class RedisKeyUtil {

    private static final String NAMESPACE          = "order-service";
    private static final String IDEMPOTENCY_SUFFIX = "idempotency";
    private static final String ORDER_SUFFIX       = "order";

    private RedisKeyUtil() {
        // Utility class – do not instantiate
    }

    /**
     * Returns the Redis key used to store an idempotency record.
     *
     * <p>Example: {@code order-service:idempotency:key_abc123}
     *
     * @param idempotencyKey the client-supplied idempotency key
     * @return Redis key string
     */
    public static String idempotencyKey(String idempotencyKey) {
        return String.join(":", NAMESPACE, IDEMPOTENCY_SUFFIX, idempotencyKey);
    }

    /**
     * Returns the Redis key used to cache an {@code Order} response.
     *
     * <p>Example: {@code order-service:order:42}
     *
     * @param orderId the order primary key
     * @return Redis key string
     */
    public static String orderCacheKey(Long orderId) {
        return String.join(":", NAMESPACE, ORDER_SUFFIX, orderId.toString());
    }
}
