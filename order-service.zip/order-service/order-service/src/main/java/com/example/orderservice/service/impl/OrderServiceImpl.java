package com.example.orderservice.service.impl;

import com.example.orderservice.config.AppProperties;
import com.example.orderservice.config.RedisConfig;
import com.example.orderservice.domain.entity.Order;
import com.example.orderservice.domain.entity.OrderItem;
import com.example.orderservice.domain.enums.OrderStatus;
import com.example.orderservice.dto.request.CreateOrderRequest;
import com.example.orderservice.dto.response.OrderResponse;
import com.example.orderservice.event.OrderCreatedEvent;
import com.example.orderservice.exception.DuplicateOrderException;
import com.example.orderservice.exception.OrderNotFoundException;
import com.example.orderservice.kafka.producer.OrderEventProducer;
import com.example.orderservice.repository.OrderRepository;
import com.example.orderservice.service.OrderService;
import com.example.orderservice.util.OrderMapper;
import com.example.orderservice.util.RedisKeyUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.List;

/**
 * Default implementation of {@link OrderService}.
 *
 * <h3>Key Flows</h3>
 *
 * <h4>Create Order</h4>
 * <ol>
 *   <li>Check Redis for idempotency key → return cached order if found.</li>
 *   <li>Check DB for idempotency key (second line of defence after Redis TTL expiry).</li>
 *   <li>Build and persist the {@link Order} aggregate in PostgreSQL inside a transaction.</li>
 *   <li>Store idempotency key in Redis with a 24-hour TTL.</li>
 *   <li>Publish {@link OrderCreatedEvent} to Kafka <em>after</em> the DB transaction commits.</li>
 * </ol>
 *
 * <h4>Get Order (Cache-Aside)</h4>
 * <ol>
 *   <li>Spring's {@code @Cacheable} checks Redis before calling the method body.</li>
 *   <li>On a cache miss, the order is fetched from PostgreSQL with items eagerly loaded.</li>
 *   <li>The result is automatically written to Redis by the {@code @Cacheable} interceptor.</li>
 * </ol>
 *
 * <h4>Update Status (from Kafka Events)</h4>
 * <ol>
 *   <li>Execute a targeted UPDATE (no full entity load) against PostgreSQL.</li>
 *   <li>Evict the stale cached order from Redis so the next read reflects the new status.</li>
 * </ol>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final OrderRepository      orderRepository;
    private final OrderMapper          orderMapper;
    private final OrderEventProducer   orderEventProducer;
    private final RedisTemplate<String, Object> redisTemplate;
    private final AppProperties        appProperties;

    // ─── Create Order ────────────────────────────────────────────────────────

    @Override
    @Transactional
    public OrderResponse createOrder(CreateOrderRequest request) {
        log.info("Processing createOrder: customerId={}, idempotencyKey={}",
                request.customerId(), request.idempotencyKey());

        // ── Step 1: Idempotency check (Redis fast path) ──────────────────────
        String redisIdempotencyKey = RedisKeyUtil.idempotencyKey(request.idempotencyKey());
        Object cachedOrderId = redisTemplate.opsForValue().get(redisIdempotencyKey);

        if (cachedOrderId != null) {
            Long existingOrderId = Long.parseLong(cachedOrderId.toString());
            log.info("Idempotency hit in Redis: returning existing orderId={}", existingOrderId);
            return getOrderById(existingOrderId);
        }

        // ── Step 2: Idempotency check (DB safety net) ────────────────────────
        if (orderRepository.existsByIdempotencyKey(request.idempotencyKey())) {
            log.warn("Idempotency key already exists in DB: key={}", request.idempotencyKey());
            throw new DuplicateOrderException(request.idempotencyKey());
        }

        // ── Step 3: Build the Order aggregate ───────────────────────────────
        Order order = Order.builder()
                .customerId(request.customerId())
                .idempotencyKey(request.idempotencyKey())
                .status(OrderStatus.PENDING)
                .build();

        List<OrderItem> items = orderMapper.toOrderItems(request.items());
        items.forEach(item -> {
            item.computeSubTotal();   // Derive subTotal before adding to aggregate
            order.addItem(item);      // Sets the back-reference: item.order = order
        });
        order.recalculateTotalPrice();

        // ── Step 4: Persist to PostgreSQL ────────────────────────────────────
        Order savedOrder = orderRepository.save(order);
        log.info("Order persisted: orderId={}, totalPrice={}", savedOrder.getId(), savedOrder.getTotalPrice());

        // ── Step 5: Store idempotency key in Redis (24 h TTL) ────────────────
        Duration idempotencyTtl = Duration.ofHours(appProperties.cache().idempotencyTtlHours());
        redisTemplate.opsForValue().set(
                redisIdempotencyKey,
                savedOrder.getId().toString(),
                idempotencyTtl
        );
        log.debug("Idempotency key stored in Redis: key={}, ttl={}", redisIdempotencyKey, idempotencyTtl);

        // ── Step 6: Publish Kafka event (after DB commit) ────────────────────
        OrderCreatedEvent event = orderMapper.toCreatedEvent(savedOrder);
        orderEventProducer.publishOrderCreated(event);

        return orderMapper.toResponse(savedOrder);
    }

    // ─── Get Order (Cache-Aside) ─────────────────────────────────────────────

    /**
     * {@code @Cacheable} intercepts this method. On a cache hit the body is never executed.
     * The cache key is {@code "orders::${orderId}"}.
     */
    @Override
    @Cacheable(cacheNames = RedisConfig.CACHE_ORDERS, key = "#orderId")
    @Transactional(readOnly = true)
    public OrderResponse getOrderById(Long orderId) {
        log.debug("Cache miss for orderId={}, loading from DB", orderId);

        Order order = orderRepository.findByIdWithItems(orderId)
                .orElseThrow(() -> new OrderNotFoundException(orderId));

        return orderMapper.toResponse(order);
    }

    // ─── Update Order Status ─────────────────────────────────────────────────

    /**
     * {@code @CacheEvict} removes the stale cached entry so subsequent reads
     * see the updated status after this transaction commits.
     */
    @Override
    @CacheEvict(cacheNames = RedisConfig.CACHE_ORDERS, key = "#orderId")
    @Transactional
    public void updateOrderStatus(Long orderId, OrderStatus newStatus) {
        log.info("Updating order status: orderId={}, newStatus={}", orderId, newStatus);

        int updated = orderRepository.updateStatusById(orderId, newStatus);
        if (updated == 0) {
            log.warn("Status update affected 0 rows for orderId={} — order may not exist", orderId);
            throw new OrderNotFoundException(orderId);
        }

        log.info("Order status updated successfully: orderId={}, status={}", orderId, newStatus);
    }
}
