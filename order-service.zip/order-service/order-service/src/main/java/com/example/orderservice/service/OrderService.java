package com.example.orderservice.service;

import com.example.orderservice.domain.enums.OrderStatus;
import com.example.orderservice.dto.request.CreateOrderRequest;
import com.example.orderservice.dto.response.OrderResponse;

/**
 * Primary port (in Hexagonal Architecture terms) for order management operations.
 *
 * <p>Separating interface from implementation allows:
 * <ul>
 *   <li>Easier unit testing via Mockito without needing to load the full Spring context.</li>
 *   <li>Swapping implementations (e.g. a read-replica-aware variant) without touching callers.</li>
 * </ul>
 */
public interface OrderService {

    /**
     * Creates a new order from the supplied request.
     *
     * <p>If the idempotency key has been seen within the last 24 hours, the previously
     * created order is returned and no duplicate is written to the database.
     *
     * @param request validated create-order payload
     * @return the persisted order as a response DTO
     */
    OrderResponse createOrder(CreateOrderRequest request);

    /**
     * Retrieves an order by its primary key.
     *
     * <p>Implements the Cache-Aside pattern: checks Redis first; on a cache miss the
     * order is loaded from PostgreSQL, written to Redis, and then returned.
     *
     * @param orderId primary key of the order
     * @return the order response DTO
     * @throws com.example.orderservice.exception.OrderNotFoundException if no order exists with that id
     */
    OrderResponse getOrderById(Long orderId);

    /**
     * Updates the status of an existing order.
     *
     * <p>Called internally by Kafka consumers after receiving payment or inventory events.
     * Also evicts the cached order from Redis so the next {@link #getOrderById} call
     * reflects the new status.
     *
     * @param orderId   primary key of the order to update
     * @param newStatus the target {@link OrderStatus}
     */
    void updateOrderStatus(Long orderId, OrderStatus newStatus);
}
