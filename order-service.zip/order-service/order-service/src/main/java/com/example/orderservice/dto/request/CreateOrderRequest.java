package com.example.orderservice.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * Inbound payload for the {@code POST /v1/orders} endpoint.
 *
 * @param customerId     Identifier of the customer placing the order.
 * @param items          Non-empty list of line items.
 * @param idempotencyKey Client-generated key (UUID recommended) ensuring exactly-once
 *                       semantics even under network retries.
 */
public record CreateOrderRequest(

        @NotBlank(message = "customerId must not be blank")
        @Size(max = 64, message = "customerId must not exceed 64 characters")
        String customerId,

        @NotEmpty(message = "Order must contain at least one item")
        @Valid
        List<OrderItemRequest> items,

        @NotBlank(message = "idempotencyKey must not be blank")
        @Size(max = 128, message = "idempotencyKey must not exceed 128 characters")
        String idempotencyKey

) {

    /**
     * A single line-item in a create-order request.
     *
     * @param productId Identifier of the product being ordered.
     * @param quantity  Number of units; must be at least 1.
     * @param unitPrice Price per unit at the time of ordering (caller-supplied for
     *                  demo purposes; in production this should come from a
     *                  Product/Pricing service via the Order service itself).
     */
    public record OrderItemRequest(

            @NotBlank(message = "productId must not be blank")
            @Size(max = 64, message = "productId must not exceed 64 characters")
            String productId,

            @NotNull(message = "quantity is required")
            @Min(value = 1, message = "quantity must be at least 1")
            Integer quantity,

            @NotNull(message = "unitPrice is required")
            @DecimalMin(value = "0.0001", message = "unitPrice must be positive")
            @Digits(integer = 15, fraction = 4, message = "unitPrice exceeds allowed precision")
            BigDecimal unitPrice

    ) {}
}
