package com.example.orderservice.event;

import java.time.Instant;

/**
 * Event consumed from the {@code payment-events} Kafka topic.
 *
 * <p>Published by the Payment Service after attempting to charge the customer.
 *
 * @param orderId    Identifier of the order this payment decision relates to.
 * @param success    {@code true} if payment was captured; {@code false} if it was declined.
 * @param reason     Human-readable reason (e.g. "Insufficient funds"). May be blank on success.
 * @param occurredAt Timestamp when the payment event was generated.
 */
public record PaymentEvent(
        Long orderId,
        boolean success,
        String reason,
        Instant occurredAt
) {}
