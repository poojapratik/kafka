package com.example.orderservice.event;

import com.example.orderservice.domain.enums.OrderStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * Event published to the {@code order-events} Kafka topic after a new order is persisted.
 *
 * <p>Downstream services (Payment, Inventory, Notification) subscribe to this event
 * to begin their respective workflows.
 *
 * @param orderId        Unique identifier of the created order.
 * @param customerId     Identifier of the customer who placed the order.
 * @param status         Initial status (always {@link OrderStatus#PENDING}).
 * @param totalPrice     Calculated total price of the order.
 * @param idempotencyKey The client-supplied idempotency key.
 * @param items          Line items included in the order.
 * @param occurredAt     Wall-clock timestamp when the event was generated.
 */
public record OrderCreatedEvent(

        Long orderId,
        String customerId,
        OrderStatus status,
        BigDecimal totalPrice,
        String idempotencyKey,
        List<OrderItemEvent> items,
        Instant occurredAt

) {

    /**
     * Embedded line-item snapshot carried inside {@link OrderCreatedEvent}.
     */
    public record OrderItemEvent(
            String productId,
            Integer quantity,
            BigDecimal unitPrice,
            BigDecimal subTotal
    ) {}
}
