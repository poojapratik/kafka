package com.example.orderservice.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.List;

/**
 * Uniform error envelope returned by {@link com.example.orderservice.exception.GlobalExceptionHandler}.
 *
 * <p>Example JSON:
 * <pre>{@code
 * {
 *   "status": 404,
 *   "error": "NOT_FOUND",
 *   "message": "Order not found with id: 42",
 *   "path": "/api/v1/orders/42",
 *   "timestamp": "2024-05-01T10:00:00Z"
 * }
 * }</pre>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorResponse(

        int status,
        String error,
        String message,
        String path,
        List<FieldError> fieldErrors,

        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant timestamp

) {

    /** Represents a single bean-validation failure. */
    public record FieldError(String field, String message) {}

    // ─── Factory methods ─────────────────────────────────────────────────────

    public static ErrorResponse of(int status, String error, String message, String path) {
        return new ErrorResponse(status, error, message, path, null, Instant.now());
    }

    public static ErrorResponse ofValidation(int status, String error, String message,
                                             String path, List<FieldError> fieldErrors) {
        return new ErrorResponse(status, error, message, path, fieldErrors, Instant.now());
    }
}
