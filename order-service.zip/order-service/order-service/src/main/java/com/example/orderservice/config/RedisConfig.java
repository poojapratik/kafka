package com.example.orderservice.config;

import com.example.orderservice.dto.response.OrderResponse;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;
import java.util.Map;

/**
 * Redis configuration providing:
 * <ul>
 *   <li>A typed {@link RedisTemplate} for programmatic cache operations (idempotency keys, order caching)</li>
 *   <li>A {@link CacheManager} for Spring's {@code @Cacheable} abstraction</li>
 * </ul>
 */
@Configuration
public class RedisConfig {

    /** Cache name constant used with {@code @Cacheable(cacheNames = CacheNames.ORDERS)} */
    public static final String CACHE_ORDERS = "orders";

    /**
     * General-purpose {@link RedisTemplate} with String keys and JSON-serialized values.
     * Used for manual cache operations (idempotency keys, etc.).
     */
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(connectionFactory);

        ObjectMapper mapper = buildObjectMapper(true);
        GenericJackson2JsonRedisSerializer jsonSerializer =
                new GenericJackson2JsonRedisSerializer(mapper);

        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(jsonSerializer);
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(jsonSerializer);
        template.afterPropertiesSet();
        return template;
    }

    /**
     * {@link CacheManager} backed by Redis with per-cache TTL configuration.
     * The default TTL is 60 minutes; the "orders" cache uses a shorter window.
     */
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory connectionFactory,
                                     AppProperties appProperties) {
        ObjectMapper mapper = buildObjectMapper(true);
        GenericJackson2JsonRedisSerializer jsonSerializer =
                new GenericJackson2JsonRedisSerializer(mapper);

        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(appProperties.cache().orderTtlMinutes()))
                .serializeKeysWith(
                        RedisSerializationContext.SerializationPair.fromSerializer(
                                new StringRedisSerializer()))
                .serializeValuesWith(
                        RedisSerializationContext.SerializationPair.fromSerializer(jsonSerializer))
                .disableCachingNullValues();

        return RedisCacheManager.builder(connectionFactory)
                .cacheDefaults(defaultConfig)
                .withInitialCacheConfigurations(Map.of(
                        CACHE_ORDERS, defaultConfig.entryTtl(
                                Duration.ofMinutes(appProperties.cache().orderTtlMinutes()))
                ))
                .build();
    }

    /**
     * Builds an {@link ObjectMapper} configured for Redis serialization.
     *
     * @param addTypeInfo when {@code true}, embeds Java type metadata so polymorphic
     *                    types can be deserialized correctly from Redis.
     */
    private ObjectMapper buildObjectMapper(boolean addTypeInfo) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        if (addTypeInfo) {
            mapper.activateDefaultTyping(
                    mapper.getPolymorphicTypeValidator(),
                    ObjectMapper.DefaultTyping.NON_FINAL,
                    JsonTypeInfo.As.PROPERTY
            );
        }
        return mapper;
    }
}
