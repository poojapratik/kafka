package com.example.orderservice.domain.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * A single line-item within an {@link Order}.
 *
 * <p>{@code subTotal} is a derived value ({@code quantity × unitPrice}) that is
 * stored in the DB as a generated column for query efficiency, and recomputed
 * in Java before persistence to keep both layers consistent.
 */
@Entity
@Table(
        name = "order_items",
        indexes = {
                @Index(name = "idx_order_items_order_id", columnList = "order_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(exclude = "order")
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_item_seq")
    @SequenceGenerator(name = "order_item_seq", sequenceName = "order_items_id_seq", allocationSize = 50)
    @EqualsAndHashCode.Include
    private Long id;

    /**
     * Owning side of the bi-directional {@link Order}-{@link OrderItem} association.
     * Marked {@code updatable = false} to prevent accidental re-parenting.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id", nullable = false, updatable = false)
    private Order order;

    @Column(name = "product_id", nullable = false, length = 64)
    private String productId;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Column(name = "unit_price", nullable = false, precision = 19, scale = 4)
    private BigDecimal unitPrice;

    /**
     * Derived value; always set via {@link #computeSubTotal()} before persist/merge.
     * The database also stores this as a generated column for fast aggregation queries.
     */
    @Column(name = "sub_total", nullable = false, precision = 19, scale = 4)
    private BigDecimal subTotal;

    /** Recomputes and sets {@code subTotal = quantity × unitPrice}. */
    public BigDecimal computeSubTotal() {
        this.subTotal = unitPrice.multiply(BigDecimal.valueOf(quantity));
        return this.subTotal;
    }
}
