package com.example.orderservice.event;

import java.time.Instant;

/**
 * Event consumed from the {@code inventory-events} Kafka topic.
 *
 * <p>Published by the Inventory Service after attempting to reserve stock.
 *
 * @param orderId    Identifier of the order this reservation decision relates to.
 * @param reserved   {@code true} if stock was successfully reserved; {@code false} otherwise.
 * @param reason     Human-readable reason (e.g. "Out of stock"). May be blank on success.
 * @param occurredAt Timestamp when the inventory event was generated.
 */
public record InventoryEvent(
        Long orderId,
        boolean reserved,
        String reason,
        Instant occurredAt
) {}
