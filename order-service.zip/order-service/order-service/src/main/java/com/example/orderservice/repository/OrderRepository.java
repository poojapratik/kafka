package com.example.orderservice.repository;

import com.example.orderservice.domain.entity.Order;
import com.example.orderservice.domain.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link Order} persistence operations.
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    /**
     * Eager-fetches the order and its line items in a single SQL query using
     * a LEFT JOIN FETCH to avoid the N+1 problem.
     *
     * @param id the primary key of the order
     * @return an {@link Optional} containing the order with items, or empty
     */
    @Query("SELECT o FROM Order o LEFT JOIN FETCH o.items WHERE o.id = :id")
    Optional<Order> findByIdWithItems(@Param("id") Long id);

    /**
     * Checks whether an order already exists for the given idempotency key.
     * Used by the service layer before attempting to create a duplicate order.
     */
    boolean existsByIdempotencyKey(String idempotencyKey);

    /**
     * Performs a targeted status update without loading the full entity graph.
     * Used by Kafka consumers to update status from payment/inventory events.
     *
     * @param orderId   the order to update
     * @param newStatus the new {@link OrderStatus}
     * @return the number of rows affected (0 or 1)
     */
    @Modifying
    @Query("UPDATE Order o SET o.status = :newStatus WHERE o.id = :orderId")
    int updateStatusById(@Param("orderId") Long orderId, @Param("newStatus") OrderStatus newStatus);
}
