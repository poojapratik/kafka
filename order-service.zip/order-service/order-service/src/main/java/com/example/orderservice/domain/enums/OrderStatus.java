package com.example.orderservice.domain.enums;

/**
 * Lifecycle states for an {@code Order}.
 *
 * <pre>
 *  PENDING ──► CONFIRMED
 *     │              │
 *     └──► CANCELLED ◄┘
 *
 *  FAILED is a terminal state set when processing encounters an unrecoverable error.
 * </pre>
 */
public enum OrderStatus {

    /** Initial state after the order is persisted; awaiting payment and inventory confirmation. */
    PENDING,

    /** Payment succeeded and inventory was reserved. */
    CONFIRMED,

    /** Payment failed, inventory was insufficient, or the order was explicitly cancelled. */
    CANCELLED,

    /** An unrecoverable processing error occurred. */
    FAILED
}
