package com.example.orderservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when a request arrives with an idempotency key that has already been used
 * to create an order within the last 24 hours.
 * Maps to HTTP {@code 409 Conflict}.
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateOrderException extends RuntimeException {

    private final String idempotencyKey;

    public DuplicateOrderException(String idempotencyKey) {
        super("Order already created for idempotency key: " + idempotencyKey);
        this.idempotencyKey = idempotencyKey;
    }

    public String getIdempotencyKey() {
        return idempotencyKey;
    }
}
