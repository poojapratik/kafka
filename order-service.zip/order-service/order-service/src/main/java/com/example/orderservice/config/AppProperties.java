package com.example.orderservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Strongly-typed binding for the {@code app.*} namespace in {@code application.yml}.
 * Avoids scattered {@code @Value} annotations and enables IDE auto-completion.
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(KafkaProperties kafka, CacheProperties cache) {

    public record KafkaProperties(TopicProperties topics) {

        public record TopicProperties(
                String orderEvents,
                String paymentEvents,
                String inventoryEvents
        ) {}
    }

    public record CacheProperties(
            long orderTtlMinutes,
            long idempotencyTtlHours
    ) {}
}
