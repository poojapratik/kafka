package com.example.orderservice.config;

import com.example.orderservice.event.OrderCreatedEvent;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.Map;

/**
 * Kafka producer infrastructure configuration.
 *
 * <p>Creates:
 * <ul>
 *   <li>A typed {@link KafkaTemplate} for {@link OrderCreatedEvent} messages</li>
 *   <li>Topic definitions with replication + partition tuned for production</li>
 * </ul>
 *
 * <p>Consumer configuration is handled by Spring Boot auto-configuration reading
 * {@code spring.kafka.consumer.*} from {@code application.yml}.
 */
@Configuration
public class KafkaConfig {

    private final AppProperties appProperties;
    private final KafkaProperties kafkaProperties;

    public KafkaConfig(AppProperties appProperties, KafkaProperties kafkaProperties) {
        this.appProperties = appProperties;
        this.kafkaProperties = kafkaProperties;
    }

    // ─── Producer ────────────────────────────────────────────────────────────

    @Bean
    public ProducerFactory<String, Object> producerFactory() {
        Map<String, Object> configs = kafkaProperties.buildProducerProperties(null);

        // Override serializer to handle any event type through this template
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        // Exactly-once producer semantics
        configs.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        configs.put(ProducerConfig.ACKS_CONFIG, "all");
        configs.put(ProducerConfig.RETRIES_CONFIG, 3);
        configs.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 1);

        return new DefaultKafkaProducerFactory<>(configs);
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    // ─── Topic Definitions ───────────────────────────────────────────────────

    /**
     * Auto-creates the {@code order-events} topic when Kafka broker is reachable.
     * In production, prefer managing topics via Terraform / Confluent Cloud instead.
     */
    @Bean
    public NewTopic orderEventsTopic() {
        return TopicBuilder
                .name(appProperties.kafka().topics().orderEvents())
                .partitions(3)
                .replicas(1)   // Increase to 3 in multi-broker clusters
                .build();
    }

    @Bean
    public NewTopic paymentEventsTopic() {
        return TopicBuilder
                .name(appProperties.kafka().topics().paymentEvents())
                .partitions(3)
                .replicas(1)
                .build();
    }

    @Bean
    public NewTopic inventoryEventsTopic() {
        return TopicBuilder
                .name(appProperties.kafka().topics().inventoryEvents())
                .partitions(3)
                .replicas(1)
                .build();
    }
}
