package com.example.orderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * Entry point for the Order Microservice.
 *
 * <p>Key Spring features enabled:
 * <ul>
 *   <li>{@code @EnableCaching}     – activates Spring Cache abstraction backed by Redis</li>
 *   <li>{@code @EnableJpaAuditing} – auto-populates {@code createdAt} / {@code updatedAt} fields</li>
 *   <li>{@code @ConfigurationPropertiesScan} – binds {@code @ConfigurationProperties} beans</li>
 * </ul>
 */
@SpringBootApplication
@EnableCaching
@EnableJpaAuditing
@ConfigurationPropertiesScan
public class OrderServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
}
