package com.example.orderservice.kafka.producer;

import com.example.orderservice.config.AppProperties;
import com.example.orderservice.event.OrderCreatedEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

/**
 * Kafka producer responsible for publishing order-domain events.
 *
 * <p>Uses the {@link KafkaTemplate} configured in
 * {@link com.example.orderservice.config.KafkaConfig} which is set up with
 * idempotent producer semantics ({@code enable.idempotence=true, acks=all}).
 *
 * <p>The partition key is the {@code orderId} serialised as a string, which
 * guarantees that all events for a given order are routed to the same partition
 * and therefore consumed in order by downstream services.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class OrderEventProducer {

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final AppProperties appProperties;

    /**
     * Publishes an {@link OrderCreatedEvent} to the {@code order-events} topic.
     *
     * <p>The send is asynchronous; the returned {@link CompletableFuture} is
     * used only for logging. If the application needs guaranteed delivery,
     * consider a transactional outbox pattern instead.
     *
     * @param event the event to publish
     */
    public void publishOrderCreated(OrderCreatedEvent event) {
        String topic      = appProperties.kafka().topics().orderEvents();
        String partitionKey = event.orderId().toString();

        log.info("Publishing OrderCreatedEvent: topic={}, orderId={}", topic, event.orderId());

        CompletableFuture<SendResult<String, Object>> future =
                kafkaTemplate.send(topic, partitionKey, event);

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                log.error("Failed to publish OrderCreatedEvent: orderId={}, error={}",
                        event.orderId(), ex.getMessage(), ex);
                // In production: persist to an outbox table and retry via a scheduled job
            } else {
                log.info("OrderCreatedEvent published successfully: orderId={}, topic={}, partition={}, offset={}",
                        event.orderId(),
                        result.getRecordMetadata().topic(),
                        result.getRecordMetadata().partition(),
                        result.getRecordMetadata().offset());
            }
        });
    }
}
