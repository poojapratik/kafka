package com.example.orderservice.controller;

import com.example.orderservice.dto.request.CreateOrderRequest;
import com.example.orderservice.dto.response.OrderResponse;
import com.example.orderservice.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller exposing the Order Service public API.
 *
 * <h3>Endpoints</h3>
 * <table border="1">
 *   <tr><th>Method</th><th>Path</th><th>Success Status</th><th>Description</th></tr>
 *   <tr><td>POST</td><td>/v1/orders</td><td>201 Created</td><td>Create a new order</td></tr>
 *   <tr><td>GET</td><td>/v1/orders/{orderId}</td><td>200 OK</td><td>Fetch order by ID (cached)</td></tr>
 * </table>
 *
 * <p>All error responses are formatted by
 * {@link com.example.orderservice.exception.GlobalExceptionHandler}.
 */
@RestController
@RequestMapping(value = "/v1/orders", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
@Slf4j
public class OrderController {

    private final OrderService orderService;

    /**
     * Creates a new order.
     *
     * <p>The {@code idempotencyKey} in the request body is used to deduplicate
     * retried requests. If a request with the same key has been processed in the
     * last 24 hours, the original order is returned with {@code 200 OK} rather
     * than {@code 201 Created}.
     *
     * @param request the validated create-order payload
     * @return {@code 201 Created} with the new {@link OrderResponse} in the body
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody CreateOrderRequest request) {
        log.info("POST /v1/orders – customerId={}, idempotencyKey={}",
                request.customerId(), request.idempotencyKey());

        OrderResponse response = orderService.createOrder(request);

        // Return 201 for new orders; the service layer handles idempotency
        // (returning an existing order when the key was already used).
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Retrieves an existing order by its primary key.
     *
     * <p>Results are cached in Redis (Cache-Aside pattern). A cache miss triggers
     * a PostgreSQL read and populates Redis transparently.
     *
     * @param orderId the primary key of the order
     * @return {@code 200 OK} with the {@link OrderResponse} in the body
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable Long orderId) {
        log.info("GET /v1/orders/{}", orderId);

        OrderResponse response = orderService.getOrderById(orderId);
        return ResponseEntity.ok(response);
    }
}
