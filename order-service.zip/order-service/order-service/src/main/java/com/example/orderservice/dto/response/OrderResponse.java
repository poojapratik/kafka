package com.example.orderservice.dto.response;

import com.example.orderservice.domain.enums.OrderStatus;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * Outbound representation of an {@code Order} resource.
 *
 * <p>Implements {@link Serializable} so it can be stored/retrieved from Redis
 * via Spring's {@link org.springframework.cache.annotation.Cacheable} mechanism.
 */
public record OrderResponse(

        Long id,
        String customerId,
        OrderStatus status,
        BigDecimal totalPrice,
        String idempotencyKey,
        List<OrderItemResponse> items,

        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant createdAt,

        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant updatedAt

) implements Serializable {

    /**
     * Outbound representation of a single order line-item.
     */
    public record OrderItemResponse(
            Long id,
            String productId,
            Integer quantity,
            BigDecimal unitPrice,
            BigDecimal subTotal
    ) implements Serializable {}
}
