package com.example.orderservice.util;

import com.example.orderservice.domain.entity.Order;
import com.example.orderservice.domain.entity.OrderItem;
import com.example.orderservice.dto.request.CreateOrderRequest;
import com.example.orderservice.dto.response.OrderResponse;
import com.example.orderservice.event.OrderCreatedEvent;
import org.mapstruct.*;

import java.time.Instant;
import java.util.List;

/**
 * MapStruct mapper providing bi-directional mappings between the domain layer
 * ({@link Order}, {@link OrderItem}) and transport/event objects
 * ({@link OrderResponse}, {@link OrderCreatedEvent}).
 *
 * <p>Using {@code componentModel = "spring"} makes this mapper a Spring bean,
 * eligible for {@code @Autowired} / constructor injection.
 */
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrderMapper {

    // ─── Entity → Response ───────────────────────────────────────────────────

    /**
     * Maps a fully-loaded {@link Order} (with items) to {@link OrderResponse}.
     */
    OrderResponse toResponse(Order order);

    /**
     * Maps a single {@link OrderItem} to its response DTO.
     */
    OrderResponse.OrderItemResponse toItemResponse(OrderItem item);

    // ─── Entity → Event ──────────────────────────────────────────────────────

    /**
     * Maps a persisted {@link Order} to the {@link OrderCreatedEvent} published on Kafka.
     * The {@code occurredAt} field is set to {@link Instant#now()} at mapping time.
     */
    @Mapping(target = "occurredAt", expression = "java(java.time.Instant.now())")
    OrderCreatedEvent toCreatedEvent(Order order);

    /**
     * Maps an {@link OrderItem} to the embedded event snapshot.
     */
    OrderCreatedEvent.OrderItemEvent toItemEvent(OrderItem item);

    // ─── Request → Entity ────────────────────────────────────────────────────

    /**
     * Converts a single {@link CreateOrderRequest.OrderItemRequest} to an {@link OrderItem}.
     * The {@code order} back-reference is intentionally ignored here; it is set by
     * {@link Order#addItem(OrderItem)} to keep both sides in sync.
     *
     * <p>{@code subTotal} is ignored because it is recomputed by
     * {@link OrderItem#computeSubTotal()} in the service layer.
     */
    @Mapping(target = "id",       ignore = true)
    @Mapping(target = "order",    ignore = true)
    @Mapping(target = "subTotal", ignore = true)
    OrderItem toOrderItem(CreateOrderRequest.OrderItemRequest itemRequest);

    /**
     * Bulk variant of {@link #toOrderItem}.
     */
    List<OrderItem> toOrderItems(List<CreateOrderRequest.OrderItemRequest> itemRequests);
}
