package com.example.orderservice.kafka.consumer;

import com.example.orderservice.domain.enums.OrderStatus;
import com.example.orderservice.event.InventoryEvent;
import com.example.orderservice.event.PaymentEvent;
import com.example.orderservice.exception.OrderNotFoundException;
import com.example.orderservice.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * Idempotent Kafka consumer that listens on {@code payment-events} and
 * {@code inventory-events} topics and updates the corresponding order status.
 *
 * <h3>Reliability Design</h3>
 * <ul>
 *   <li><strong>Manual ACK</strong> – offsets are committed only after the
 *       database update succeeds, preventing silent data loss on restarts.</li>
 *   <li><strong>Idempotency</strong> – {@link OrderService#updateOrderStatus} is
 *       idempotent: applying the same status twice is a no-op at the DB level.</li>
 *   <li><strong>Error handling</strong> – {@link OrderNotFoundException} is caught
 *       and logged rather than re-throwing, so a missing order does not cause the
 *       consumer to endlessly retry a non-actionable message. For genuinely
 *       transient errors (DB unavailable) the exception propagates and Spring-Kafka
 *       retries according to its BackOff policy.</li>
 * </ul>
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class OrderEventConsumer {

    private final OrderService orderService;

    // ─── Payment Events ──────────────────────────────────────────────────────

    /**
     * Listens to {@code payment-events} and updates order status to
     * {@link OrderStatus#CONFIRMED} on success or {@link OrderStatus#CANCELLED} on failure.
     *
     * @param event       deserialized payment event
     * @param partition   Kafka partition (for logging / debugging)
     * @param offset      Kafka offset (for logging / debugging)
     * @param ack         manual acknowledgement handle
     */
    @KafkaListener(
            topics     = "${app.kafka.topics.payment-events}",
            groupId    = "${spring.kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void handlePaymentEvent(
            @Payload PaymentEvent event,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset,
            Acknowledgment ack) {

        log.info("Received PaymentEvent: orderId={}, success={}, partition={}, offset={}",
                event.orderId(), event.success(), partition, offset);

        try {
            OrderStatus newStatus = event.success() ? OrderStatus.CONFIRMED : OrderStatus.CANCELLED;
            orderService.updateOrderStatus(event.orderId(), newStatus);
            log.info("Order status updated from PaymentEvent: orderId={}, status={}",
                    event.orderId(), newStatus);

            ack.acknowledge();
        } catch (OrderNotFoundException ex) {
            // The order may have been deleted or never existed; acknowledge to prevent
            // infinite retry of an unresolvable message.
            log.warn("OrderNotFound during payment processing – acknowledging to skip: orderId={}",
                    event.orderId());
            ack.acknowledge();
        } catch (Exception ex) {
            // Do NOT acknowledge; let Spring-Kafka retry with backoff.
            log.error("Error processing PaymentEvent for orderId={}: {}",
                    event.orderId(), ex.getMessage(), ex);
            throw ex;
        }
    }

    // ─── Inventory Events ────────────────────────────────────────────────────

    /**
     * Listens to {@code inventory-events} and updates order status to
     * {@link OrderStatus#CONFIRMED} on successful reservation or
     * {@link OrderStatus#CANCELLED} if stock was insufficient.
     *
     * @param event       deserialized inventory event
     * @param partition   Kafka partition (for logging / debugging)
     * @param offset      Kafka offset (for logging / debugging)
     * @param ack         manual acknowledgement handle
     */
    @KafkaListener(
            topics     = "${app.kafka.topics.inventory-events}",
            groupId    = "${spring.kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void handleInventoryEvent(
            @Payload InventoryEvent event,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset,
            Acknowledgment ack) {

        log.info("Received InventoryEvent: orderId={}, reserved={}, partition={}, offset={}",
                event.orderId(), event.reserved(), partition, offset);

        try {
            OrderStatus newStatus = event.reserved() ? OrderStatus.CONFIRMED : OrderStatus.CANCELLED;
            orderService.updateOrderStatus(event.orderId(), newStatus);
            log.info("Order status updated from InventoryEvent: orderId={}, status={}",
                    event.orderId(), newStatus);

            ack.acknowledge();
        } catch (OrderNotFoundException ex) {
            log.warn("OrderNotFound during inventory processing – acknowledging to skip: orderId={}",
                    event.orderId());
            ack.acknowledge();
        } catch (Exception ex) {
            log.error("Error processing InventoryEvent for orderId={}: {}",
                    event.orderId(), ex.getMessage(), ex);
            throw ex;
        }
    }
}
