# Order Microservice

Production-ready Order Microservice built with **Spring Boot 3.x**, **Java 17**, **PostgreSQL**, **Redis**, and **Apache Kafka**.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Order Microservice                                │
│                                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │  Controller  │───▶│   Service    │───▶│  Repository  │──▶ PostgreSQL    │
│  │  (REST API)  │    │  (Business   │    │  (JPA/Data)  │                  │
│  └──────────────┘    │   Logic)     │    └──────────────┘                  │
│                      │              │                                       │
│                      │  ┌────────┐  │    ┌──────────────┐                  │
│                      │  │ Redis  │◀─┤───▶│  Redis       │ Cache-Aside +    │
│                      │  │ Cache  │  │    │  (Idempotency│ Idempotency      │
│                      │  └────────┘  │    │   + Cache)   │                  │
│                      └──────┬───────┘    └──────────────┘                  │
│                             │                                               │
│                    ┌────────▼────────┐                                      │
│                    │ Kafka Producer  │──▶ order-events topic                │
│                    └─────────────────┘                                      │
│                                                                             │
│  ┌──────────────────────────────────────┐                                   │
│  │         Kafka Consumers              │                                   │
│  │  payment-events ──▶ updateStatus()   │                                   │
│  │  inventory-events ▶ updateStatus()   │                                   │
│  └──────────────────────────────────────┘                                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
order-service/
├── Dockerfile
├── docker-compose.yml          ← Local dev infra (PG, Redis, Kafka)
├── pom.xml
└── src/
    ├── main/
    │   ├── java/com/example/orderservice/
    │   │   ├── OrderServiceApplication.java
    │   │   ├── config/
    │   │   │   ├── AppProperties.java      ← Typed config binding
    │   │   │   ├── KafkaConfig.java        ← Producer + topic beans
    │   │   │   ├── KafkaConsumerConfig.java← Consumer factory (manual ACK)
    │   │   │   └── RedisConfig.java        ← RedisTemplate + CacheManager
    │   │   ├── controller/
    │   │   │   └── OrderController.java    ← POST /v1/orders, GET /v1/orders/{id}
    │   │   ├── domain/
    │   │   │   ├── entity/
    │   │   │   │   ├── Order.java          ← Aggregate root (JPA Entity)
    │   │   │   │   └── OrderItem.java      ← Line-item (JPA Entity)
    │   │   │   └── enums/
    │   │   │       └── OrderStatus.java    ← PENDING|CONFIRMED|CANCELLED|FAILED
    │   │   ├── dto/
    │   │   │   ├── request/
    │   │   │   │   └── CreateOrderRequest.java
    │   │   │   └── response/
    │   │   │       ├── ErrorResponse.java
    │   │   │       └── OrderResponse.java
    │   │   ├── event/
    │   │   │   ├── OrderCreatedEvent.java  ← Published to order-events
    │   │   │   ├── PaymentEvent.java       ← Consumed from payment-events
    │   │   │   └── InventoryEvent.java     ← Consumed from inventory-events
    │   │   ├── exception/
    │   │   │   ├── DuplicateOrderException.java
    │   │   │   ├── GlobalExceptionHandler.java ← @ControllerAdvice
    │   │   │   ├── InvalidOrderException.java
    │   │   │   └── OrderNotFoundException.java
    │   │   ├── kafka/
    │   │   │   ├── consumer/
    │   │   │   │   └── OrderEventConsumer.java ← Payment + Inventory consumers
    │   │   │   └── producer/
    │   │   │       └── OrderEventProducer.java ← Publishes OrderCreatedEvent
    │   │   ├── repository/
    │   │   │   └── OrderRepository.java
    │   │   ├── service/
    │   │   │   ├── OrderService.java       ← Interface (port)
    │   │   │   └── impl/
    │   │   │       └── OrderServiceImpl.java ← Implementation
    │   │   └── util/
    │   │       ├── OrderMapper.java        ← MapStruct mapper
    │   │       └── RedisKeyUtil.java       ← Key namespace constants
    │   └── resources/
    │       ├── application.yml
    │       └── schema.sql                 ← PostgreSQL DDL
    └── test/
        └── java/com/example/orderservice/
            ├── controller/
            │   └── OrderControllerTest.java  ← @WebMvcTest slice
            └── service/
                └── OrderServiceImplTest.java ← Pure unit tests
```

---

## Quick Start (Local)

### Prerequisites
- Java 17+, Maven 3.8+, Docker Desktop

### 1. Start infrastructure
```bash
docker compose up -d
# Wait for health checks to pass (≈ 30 s)
```

### 2. Run the application
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

### 3. Test the API
```bash
# Create an order
curl -s -X POST http://localhost:8080/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "cust-123",
    "idempotencyKey": "550e8400-e29b-41d4-a716-446655440000",
    "items": [
      { "productId": "prod-abc", "quantity": 2, "unitPrice": 49.99 }
    ]
  }' | jq .

# Fetch the order (first call loads from DB; subsequent calls hit Redis)
curl -s http://localhost:8080/api/v1/orders/1 | jq .

# View Kafka topics in the UI
open http://localhost:8090
```

---

## Key Design Decisions

| Concern | Decision | Rationale |
|---|---|---|
| Idempotency | Redis primary check + DB unique constraint fallback | Redis is fast (O(1)); DB constraint is the safety net after TTL expiry |
| Cache-Aside | `@Cacheable` on `getOrderById` | Spring manages the Redis read/write; no boilerplate |
| Cache eviction | `@CacheEvict` on `updateOrderStatus` | Ensures stale PENDING data isn't served after CONFIRMED/CANCELLED |
| Kafka ACK | `MANUAL_IMMEDIATE` | Offset committed only after DB write succeeds; prevents silent loss on restart |
| Producer idempotence | `enable.idempotence=true, acks=all` | Exactly-once writes even under broker retries |
| Status update query | `@Modifying @Query UPDATE …` | Avoids loading the full entity + items graph for a simple status change |
| Error serialisation | `ErrorHandlingDeserializer` wrapper | Malformed Kafka messages don't crash the consumer thread |

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `DB_HOST` | `localhost` | PostgreSQL host |
| `DB_PORT` | `5432` | PostgreSQL port |
| `DB_NAME` | `orderdb` | Database name |
| `DB_USERNAME` | `postgres` | Database user |
| `DB_PASSWORD` | `postgres` | Database password |
| `REDIS_HOST` | `localhost` | Redis host |
| `REDIS_PORT` | `6379` | Redis port |
| `REDIS_PASSWORD` | _(empty)_ | Redis password |
| `KAFKA_BOOTSTRAP_SERVERS` | `localhost:9092` | Kafka bootstrap servers |
| `SERVER_PORT` | `8080` | HTTP server port |
